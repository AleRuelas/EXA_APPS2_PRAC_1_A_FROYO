package com.example.exa_apps2_prac_1_a_froyo_frag_din;

import android.os.Bundle;
import android.widget.FrameLayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

public class MainActivity extends AppCompatActivity {
    FrameLayout frame1,frame2,frame3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        frame1 =  findViewById(R.id.frame1);
        frame2 =  findViewById(R.id.frame2);
        frame3 =  findViewById(R.id.frame3);

        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        Fragmento1 uno = new Fragmento1();
        Fragmento2 dos = new Fragmento2();
        Fragmento3 tres = new Fragmento3();
        ft.replace(R.id.frame1, uno);
        ft.replace(R.id.frame2, dos);
        ft.replace(R.id.frame3, tres);
        ft.commit();
    }
}
