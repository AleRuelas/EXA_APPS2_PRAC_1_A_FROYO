package com.example.exa_apps2_prac_1_a_froyo_mostrar_imagen;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.transition.Scene;
import android.transition.Slide;
import android.transition.Transition;
import android.transition.TransitionInflater;
import android.transition.TransitionManager;
import android.transition.TransitionValues;
import android.util.Log;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.SeekBar;

public class MainActivity extends AppCompatActivity {

    /*
    * EXAMEN PRACTICO EVALUACION 1
    * APLICACIONES MOVILES II
    * EQUIPO FROYO
    * INTEGRANTES:
    *   FRANCISCO JAVIER RAMIREZ LUNA 16550546
    *   ALEJANDRA RUELAS NAJERA 16550553
    *   CINTHIA PAOLA VAZQUEZ LERMA 16550544
    *
    *
    * */


    //DECLARACION DE VARIABLES GLOBALES
    Scene s1, s2, s3;
    FrameLayout frameI;
    SeekBar seek;
    ViewGroup frame1, frame2, frame3, frameD;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //VINCULACION DE LOS WIDGETS
        seek = findViewById(R.id.seekBar);
        frameI = findViewById(R.id.frm1);
        frame1 = findViewById(R.id.frm1);
        frame2 = findViewById(R.id.frm2);
        frame3 = findViewById(R.id.frm3);
        frameD = findViewById(R.id.frmp);

        //CONDICION PARA CUANDO INICIA LA APLICACION SIN EL USO DEL SEEKBAR
        if (isPortrait()){//CONDICION: FUNCION PARA VERIFICAR EN QUE ORIENTACION ESTA LA PANTALLA
            //COLOCACION DE LA PRIMERA ESCENA EN MODO PORTRAIT
            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec1, MainActivity.this);
            s1.enter();
        }else {
            //COLOCACION DE LA PRIMERA ESCENA EN MODO LANDSCAPE
            s1 = Scene.getSceneForLayout(frame1, R.layout.escsecd, MainActivity.this);
            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec1, MainActivity.this);
            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec2, MainActivity.this);
            s1.enter();
            s2.enter();
            s3.enter();
        }

        //SOBRESCRITURA DEL EVENTO DEL SEEKBAR
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {

            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                switch(progress){//SWITCH CASE PARA CONTROLAR LAS TRANSICIONES CON EL SEEKBAR PARA LAS 10 TRANSICIONES
                    case 0:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec1, MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);//TRANSICION HACIA LA DERECHA
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsecd, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec1, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec2, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 1:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec2, MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec1, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec2, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec3, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 2:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec3, MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec2, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec3, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec4, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 3:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec4, MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec3, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec4, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec5, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 4:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec5 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec4, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec5, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec6, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 5:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec6 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec5, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec6, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec7, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 6:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec7 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec6, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec7, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec8, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 7:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec8 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec7, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec8, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec9, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 8:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec9 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec8, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec9, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsec10, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                    case 9:
                        if (isPortrait()){
                            s1 = Scene.getSceneForLayout(frameD, R.layout.escsec10 , MainActivity.this);
                            Transition fade = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, fade);
                        }else {
                            s1 = Scene.getSceneForLayout(frame1, R.layout.escsec9, MainActivity.this);
                            s2 = Scene.getSceneForLayout(frame2, R.layout.escsec10, MainActivity.this);
                            s3 = Scene.getSceneForLayout(frame3, R.layout.escsecd, MainActivity.this);
                            Transition transition = new Slide(Gravity.RIGHT);
                            TransitionManager.go(s1, transition);
                            TransitionManager.go(s2, transition);
                            TransitionManager.go(s3, transition);
                        }
                        break;
                }
            }
            //METODOS SIN USO DEL LA CLASE ONSEEKBARCHANGELISTENER
            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }
    //FUNCION PARA COMPROBAR LA ORIENTACION DE LA PATALLA
    public boolean isPortrait(){
        if (frameI != null){//modo landscape
            return false;
        }else {// modo portrait
            return true;
        }
    }



}
