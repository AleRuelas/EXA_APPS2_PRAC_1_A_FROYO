package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class RomboFrag extends Fragment {
    TextView txtResul;
    EditText edDMayor, edDMenor;
    Button btnCalcular;
    double area, diagMayor, diagMenor;

    public RomboFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_rombo, container, false);
        edDMayor = linearLayout.findViewById(R.id.edDiagMayor);
        edDMenor = linearLayout.findViewById(R.id.edDiagMenor);
        btnCalcular = linearLayout.findViewById(R.id.btnCalcular);
        txtResul = linearLayout.findViewById(R.id.txtResult);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edDMayor.getText().toString().trim().length() == 0 || edDMenor.getText().toString().trim().length() == 0){
                    Toast.makeText(getActivity(),"Ingresa los datos", Toast.LENGTH_LONG).show();
                }else{
                    diagMayor = Double.parseDouble(edDMayor.getText().toString());
                    diagMenor = Double.parseDouble(edDMenor.getText().toString());
                    area = (diagMayor * diagMenor) / 2;
                    txtResul.setText("Resultado: "+area);
                }
            }
        });
        return linearLayout;
    }

}
