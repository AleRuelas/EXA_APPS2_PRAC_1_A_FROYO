package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class TrapecioFrag extends Fragment {
    TextView txtResul;
    EditText edBaseMayor, edBaseMenor, edAltura;
    Button btnCalcular;
    double area, baseMayor, baseMenor, altura;

    public TrapecioFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_trapecio, container, false);
        edBaseMayor = linearLayout.findViewById(R.id.edBaseMayor);
        edBaseMenor = linearLayout.findViewById(R.id.edBaseMenor);
        edAltura = linearLayout.findViewById(R.id.edAltura);
        btnCalcular = linearLayout.findViewById(R.id.btnCalcular);
        txtResul = linearLayout.findViewById(R.id.txtResult);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edBaseMayor.getText().toString().trim().length() == 0 || edBaseMenor.getText().toString().trim().length() == 0 || edAltura.getText().toString().trim().length() == 0){
                    Toast.makeText(getActivity(),"Ingresa los datos", Toast.LENGTH_LONG).show();
                }else{
                    baseMayor = Double.parseDouble(edBaseMayor.getText().toString());
                    baseMenor = Double.parseDouble(edBaseMenor.getText().toString());
                    altura = Double.parseDouble(edAltura.getText().toString());
                    area = (((baseMayor * baseMenor) * altura) / 2);
                    txtResul.setText("Resultado: "+area);
                }
            }
        });
        return linearLayout;
    }

}
