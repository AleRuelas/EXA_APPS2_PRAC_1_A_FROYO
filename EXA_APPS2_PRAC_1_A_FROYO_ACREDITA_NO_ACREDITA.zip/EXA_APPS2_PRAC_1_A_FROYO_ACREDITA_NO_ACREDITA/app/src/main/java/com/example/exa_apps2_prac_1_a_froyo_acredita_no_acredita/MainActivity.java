package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
/*
 * EXAMEN PRACTICO EVALUACION 1
 * APLICACIONES MOVILES II
 * EQUIPO FROYO
 * INTEGRANTES:
 *   FRANCISCO JAVIER RAMIREZ LUNA 16550546
 *   ALEJANDRA RUELAS NAJERA 16550553
 *   CINTHIA PAOLA VAZQUEZ LERMA 16550544
 *
 *
 * */

public class MainActivity extends AppCompatActivity {
    //DECLARACIÓN DEL FRAGMENTO LISTA
    ListFragment listFragment;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //CREACION DEL FRAGMENTO DINAMICO DE LISTFRAGMENT
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        //ANIMACION DE LA TRANSICION DEL FRAGMENTO
        ft.setCustomAnimations(R.anim.anim_barrido,R.anim.anim_barrido,R.anim.anim_barrido,R.anim.anim_barrido);
        listFragment = new ListFragment();
        //SE REMPLAZA EL LISTFRAGMENT EN EL FRAMELAYOUT DE LA ACTIVIDAD PRINCIPAL
        ft.replace(R.id.FrameLayout, listFragment);
        ft.commit();

    }
    //METODO PARA RECIBIR VALORES DEL LISTFRAGMENT
    public void onMessageFromFragToMain(String position) {
        //CONDICIONES PARA EL ESCUCHADOR DEL LISTFRAGMENT
        if (position == "Circulo") {
            FragmentTransaction ft2 = getSupportFragmentManager().beginTransaction();
            ft2.setCustomAnimations(R.anim.anim_zoomentrada,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            CirculoFrag circuloFrag = new CirculoFrag();
            ft2.replace(R.id.FrameLayout, circuloFrag);
            ft2.addToBackStack("1");
            ft2.commit();
        } else if (position == "Cuadrado"){
            FragmentTransaction ft3 = getSupportFragmentManager().beginTransaction();
            ft3.setCustomAnimations(R.anim.anim_new,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            CuadradoFrag cuadradoFrag = new CuadradoFrag();
            ft3.replace(R.id.FrameLayout, cuadradoFrag);
            ft3.addToBackStack("1");
            ft3.commit();
        } else if (position == "Esfera"){
            FragmentTransaction ft4 = getSupportFragmentManager().beginTransaction();
            ft4.setCustomAnimations(R.anim.anim_giro,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            EsferaFrag esferaFrag = new EsferaFrag();
            ft4.replace(R.id.FrameLayout, esferaFrag);
            ft4.addToBackStack("1");
            ft4.commit();
        } else if (position == "Hexágono"){
            FragmentTransaction ft5 = getSupportFragmentManager().beginTransaction();
            ft5.setCustomAnimations(R.anim.anim_zoomentrada,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            HexagonoFrag  hexagonoFrag = new HexagonoFrag();
            ft5.replace(R.id.FrameLayout, hexagonoFrag);
            ft5.addToBackStack("1");
            ft5.commit();
        } else if (position == "Paralelogramo"){
            FragmentTransaction ft6 = getSupportFragmentManager().beginTransaction();
            ft6.setCustomAnimations(R.anim.anim_new,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            ParalelogramoFrag paralelogramoFrag = new ParalelogramoFrag();
            ft6.replace(R.id.FrameLayout, paralelogramoFrag);
            ft6.addToBackStack("1");
            ft6.commit();
        } else if (position == "Pentágono"){
            FragmentTransaction ft7 = getSupportFragmentManager().beginTransaction();
            ft7.setCustomAnimations(R.anim.anim_zoomentrada,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            PentagonoFrag pentagonoFrag = new PentagonoFrag();
            ft7.replace(R.id.FrameLayout, pentagonoFrag);
            ft7.addToBackStack("1");
            ft7.commit();
        } else if (position == "Rectángulo"){
            FragmentTransaction ft8 = getSupportFragmentManager().beginTransaction();
            ft8.setCustomAnimations(R.anim.anim_new,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            RectanguloFrag rectanguloFrag = new RectanguloFrag();
            ft8.replace(R.id.FrameLayout, rectanguloFrag);
            ft8.addToBackStack("1");
            ft8.commit();
        } else if (position == "Rombo"){
            FragmentTransaction ft9 = getSupportFragmentManager().beginTransaction();
            ft9.setCustomAnimations(R.anim.anim_zoomentrada,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            RomboFrag romboFrag = new RomboFrag();
            ft9.replace(R.id.FrameLayout, romboFrag);
            ft9.addToBackStack("1");
            ft9.commit();
        } else if (position == "Trapecio"){
            FragmentTransaction ft10 = getSupportFragmentManager().beginTransaction();
            ft10.setCustomAnimations(R.anim.anim_new,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            TrapecioFrag trapecioFrag = new TrapecioFrag();
            ft10.replace(R.id.FrameLayout, trapecioFrag);
            ft10.addToBackStack("1");
            ft10.commit();
        } else if (position == "Triángulo"){
            FragmentTransaction ft11 = getSupportFragmentManager().beginTransaction();
            ft11.setCustomAnimations(R.anim.anim_zoomentrada,R.anim.anim_emty,R.anim.anim_zoomsalida,R.anim.anim_emty);
            TringuloFrag tringuloFrag = new TringuloFrag();
            ft11.replace(R.id.FrameLayout, tringuloFrag);
            ft11.addToBackStack("1");
            ft11.commit();
        }
    }





}
