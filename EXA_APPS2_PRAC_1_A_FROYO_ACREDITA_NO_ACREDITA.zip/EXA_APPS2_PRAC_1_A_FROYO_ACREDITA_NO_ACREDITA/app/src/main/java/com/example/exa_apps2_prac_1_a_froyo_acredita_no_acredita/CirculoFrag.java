package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.app.Activity;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import static androidx.core.content.ContextCompat.getSystemService;


/**
 * A simple {@link Fragment} subclass.
 */
public class CirculoFrag extends Fragment {
    //DECLARACION DE COMPONENTES Y VARIABLES
    TextView txtResul;
    EditText edRadio;
    Button btnCalcular;
    double area, radio;

    public CirculoFrag() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_circulo, container, false);
        //VINCULACION DE LOS COMPONENTES DEL FRAGMENTO
        edRadio = linearLayout.findViewById(R.id.edRadio);
        btnCalcular = linearLayout.findViewById(R.id.btnCalcular);
        txtResul = linearLayout.findViewById(R.id.txtResult);
        //ESCUCHADOR DEL BOTON CALCULAR
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //CONDICION PARA REALIZAR LA OPERACION SI NINGUNO DE LOS CAMPOS ESTA VACIO
                if(edRadio.getText().toString().trim().length() == 0){
                    Toast.makeText(getActivity(),"Ingresa los datos", Toast.LENGTH_LONG).show();
                }else{
                    //ASIGNACION DE LAS OPERACIONES ARITMETICAS SEGUN SU FORMULA
                    radio = Double.parseDouble(edRadio.getText().toString());
                    area = (Math.PI)*(radio * radio);
                    //SE MUESTRA EL RESULTADO EN LA ETIQUETA
                    txtResul.setText("Resultado: "+area);
                }
            }
        });
        return linearLayout;
    }
}
