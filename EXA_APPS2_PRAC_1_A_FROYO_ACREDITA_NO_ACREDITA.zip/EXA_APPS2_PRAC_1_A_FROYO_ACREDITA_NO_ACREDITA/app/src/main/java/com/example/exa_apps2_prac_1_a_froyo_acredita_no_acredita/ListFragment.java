package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.transition.Fade;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class ListFragment extends Fragment {
    MainActivity main;
    //ARREGLO CON LA INFORMACIÓN DE LA LISTA DE FORMULAS
    String[] figures = {"Circulo",
            "Cuadrado",
            "Esfera",
            "Hexágono",
            "Paralelogramo",
            "Pentágono",
            "Rectángulo",
            "Rombo",
            "Trapecio",
            "Triángulo"};

    public ListFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        FrameLayout frameLayout = (FrameLayout) inflater.inflate(R.layout.fragment_list, container, false);
        ListView list = frameLayout.findViewById(R.id.figuresList);
        //ADAPTADOR PARA ASOCIAR LA INFORMACIÓN DEL ARRAY CON LOS RENGLONES DE LA LISTA
        list.setAdapter(new ArrayAdapter<>(
                main,
                android.R.layout.simple_list_item_1,
                figures
        ));

        //ESCUCHADOR PARA RESPONDER AL CLICK DE UN ITEM DE LA LISTA
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                //SE ENVIA A LA ACTIVIDAD PRINCIPAL EL RENGLON SELECCIONADO DE LA LISTA
                main.onMessageFromFragToMain(figures[i]);
            }
        });
        return  frameLayout;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        main = (MainActivity)getActivity();
    }
}
