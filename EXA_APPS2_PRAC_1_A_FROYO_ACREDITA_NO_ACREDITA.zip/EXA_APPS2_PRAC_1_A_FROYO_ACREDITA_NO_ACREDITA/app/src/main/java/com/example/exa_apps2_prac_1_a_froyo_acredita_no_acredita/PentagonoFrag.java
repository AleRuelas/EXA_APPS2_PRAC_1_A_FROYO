package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class PentagonoFrag extends Fragment {
    TextView txtResul;
    EditText edLado, edApotema;
    Button btnCalcular;
    double area, perimetro, lado, apotema;

    public PentagonoFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_hexagono, container, false);
        edLado = linearLayout.findViewById(R.id.edLado);
        edApotema = linearLayout.findViewById(R.id.edApotema);
        btnCalcular = linearLayout.findViewById(R.id.btnCalcular);
        txtResul = linearLayout.findViewById(R.id.txtResult);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edLado.getText().toString().trim().length() == 0 || edApotema.getText().toString().trim().length() == 0){
                    Toast.makeText(getActivity(),"Ingresa los datos", Toast.LENGTH_LONG).show();
                }else{
                    lado = Double.parseDouble(edLado.getText().toString());
                    apotema = Double.parseDouble(edApotema.getText().toString());
                    perimetro = (5 * lado);
                    area = (perimetro * apotema)/2;
                    txtResul.setText("Resultado: "+area);
                }
            }
        });
        return linearLayout;
    }

}
