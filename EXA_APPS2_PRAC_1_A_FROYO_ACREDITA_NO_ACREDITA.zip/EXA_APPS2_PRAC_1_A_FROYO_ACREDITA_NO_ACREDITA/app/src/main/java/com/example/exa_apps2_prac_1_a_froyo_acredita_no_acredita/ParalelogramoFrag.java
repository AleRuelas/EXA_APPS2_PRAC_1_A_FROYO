package com.example.exa_apps2_prac_1_a_froyo_acredita_no_acredita;


import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class ParalelogramoFrag extends Fragment {
    TextView txtResul;
    EditText edBase, edAltura;
    Button btnCalcular;
    double area, base, altura;

    public ParalelogramoFrag() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        LinearLayout linearLayout = (LinearLayout)inflater.inflate(R.layout.fragment_paralelogramo, container, false);
        edBase = linearLayout.findViewById(R.id.edBase);
        edAltura = linearLayout.findViewById(R.id.edAltura);
        btnCalcular = linearLayout.findViewById(R.id.btnCalcular);
        txtResul = linearLayout.findViewById(R.id.txtResult);
        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(edBase.getText().toString().trim().length() == 0 || edAltura.getText().toString().trim().length() == 0){
                    Toast.makeText(getActivity(),"Ingresa los datos", Toast.LENGTH_LONG).show();
                }else{
                    base = Double.parseDouble(edBase.getText().toString());
                    altura = Double.parseDouble(edAltura.getText().toString());
                    area = (base * altura);
                    txtResul.setText("Resultado: "+area);
                }
            }
        });
        return linearLayout;
    }

}
